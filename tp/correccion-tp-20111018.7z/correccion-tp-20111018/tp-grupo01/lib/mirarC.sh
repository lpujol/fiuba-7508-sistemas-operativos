#! /bin/sh
#
# mirar.sh
# Script parar mirar logs
#
# de Nikolaus Schneider para el trabajo practico
# de la MAteria Sistemas Operativos
#
# last change: 2011-09-25

./loguearC.sh -v $1 $2 $3 $4 $5 $6 $7 $8
