#!/bin/bash
# StartD - Inicia el daemon detectarC
nohup $1 > /dev/null 2>&1 &
