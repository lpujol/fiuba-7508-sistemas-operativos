#include <stdio.h>

util_uno()
{
    printf("En util_uno()\n");
}
