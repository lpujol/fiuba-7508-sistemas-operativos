#include <stdio.h>

util_dos()
{
    printf("En util_dos()\n");
}
