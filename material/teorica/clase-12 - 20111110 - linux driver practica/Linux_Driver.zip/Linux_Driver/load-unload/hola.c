#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>

// para que no proteste por "Kernel contaminado"
MODULE_LICENSE("Dual BSD/GPL");

static int hola_comienzo(void) {

// No hay coma entre la prioridad del mensaje (<1>) y el msje
  printk("<1> Hola Che!\n");
  return 0;
}

static void hola_final(void) {
  printk("<1> Adios, me las tomo\n");
}

module_init(hola_comienzo);
module_exit(hola_final);