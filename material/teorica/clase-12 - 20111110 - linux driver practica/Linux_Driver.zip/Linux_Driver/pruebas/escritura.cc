#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;

int main(int argct, char * argv[]){
	if (argct !=3) {
		cerr<<"uso"<<argv[0]<<" dispositivo caracter"<<endl;
		exit (1);
		}
	ofstream sal(argv[1]);
	string s(argv[2]);
	sal<<s;
	cout<<"Escrito "<<s<<" en "<<argv[1]<<endl;
}
