#include <stdio.h>


typedef struct  {
     int clas;
     int roll;
     char name[25];
}student;

void imp (student st){
	printf("( %d, %d, %s)",st.clas,st.roll,st.name);
	}
	
int main(){
	student st1={11,1,"Alan"};   // tradicional, vale en C y C++
	imp (st1);
	printf("\n");
	student st2={				 // roll no esta inicializado
		.name="Juan", .clas=4 };  // C99 no vale en c++
	imp (st2);
	printf("\n");
	student st3={
		name:"Pedro", clas:8};   // gnu C extension no vale en C++
	imp (st3);
	printf("\n");
}
