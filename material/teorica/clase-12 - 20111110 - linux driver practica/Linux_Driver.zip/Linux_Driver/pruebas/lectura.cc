#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;

int main(int argct, char * argv[]){
	if (argct !=2) {
		cerr<<"uso"<<argv[0]<<" dispositivo"<<endl;
		exit (1);
		}
	ifstream ent (argv[1]);
	string s;
	ent>>s;
	cout<<"Leido "<<s<<" de "<<argv[1]<<endl;
}
