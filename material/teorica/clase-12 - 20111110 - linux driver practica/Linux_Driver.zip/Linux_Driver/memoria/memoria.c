#include <linux/init.h>
//#include <linux/config.h>
#include <linux/module.h>
#include <linux/kernel.h> /* printk() */
#include <linux/slab.h> /* kmalloc() */
#include <linux/fs.h> /* everything... */
#include <linux/errno.h> /* error codes */
#include <linux/types.h> /* size_t */
#include <linux/proc_fs.h>
#include <linux/fcntl.h> /* O_ACCMODE */
#include <asm/system.h> /* cli(), *_flags */
#include <asm/uaccess.h> /* copy_from/to_user */


MODULE_LICENSE("Dual BSD/GPL");
/* Declaracion de las funciones */
int memoria_open(struct inode *inode, struct file *filp);
int memoria_release(struct inode *inode, struct file *filp);
ssize_t memoria_read(struct file *filp, char *buf, size_t count, loff_t *f_pos);
ssize_t memoria_write(struct file *filp, char *buf, size_t count, loff_t *f_pos);
void memoria_exit(void);
int memoria_init(void);
/* Estructura de las operaciones*/

struct file_operations memoria_fops = {
  read: memoria_read,
  write: memoria_write,
  open: memoria_open,
  release: memoria_release
};


module_init(memoria_init);
module_exit(memoria_exit);

/* Major number */
int memoria_major = 60;
/* Buffer */

char *memoria_buffer;

int memoria_init(void) {
  int result;
  /* Registrando device */
  result = register_chrdev(memoria_major, "memoria", &memoria_fops);
  if (result < 0) {
    printk(
      "<1>memoria: no se obtiene el major number %d\n", memoria_major);
    return result;
  }
  /* Reservar memoria para el buffer */
  memoria_buffer = kmalloc(1, GFP_KERNEL);
  if (!memoria_buffer) {
    result = -ENOMEM;
    memoria_exit();
    return result;
  }
  memset(memoria_buffer, 0, 1);
  printk("<1>Cargando memoria module\n");
  return 0;
}
void memoria_exit(void) {
  /* Liberar el major number */
  unregister_chrdev(memoria_major, "memoria");
  /* Liberar el buffer */
  if (memoria_buffer) {
    kfree(memoria_buffer);
  }
  printk("<1>Descargando memoria module\n");
}
int memoria_release(struct inode *inode, struct file *filp) {
  return 0;
}

int memoria_open(struct inode *inode, struct file *filp) {
  return 0;
}
ssize_t memoria_read(struct file *filp, char *buf,
                    size_t count, loff_t *f_pos) {
  /* Pasar datos al user space */
  copy_to_user(buf,memoria_buffer,1);
  /* Posicion de lectura */
  if (*f_pos == 0) {
  	*f_pos+=1; 
    return 1;    // un caracter leido
  } else {
    return 0;   // eof (vacio)
  }
}
ssize_t memoria_write( struct file *filp, char *buf,
                      size_t count, loff_t *f_pos) {
  char *tmp;
  tmp=buf; // el primer caracter
  copy_from_user(memoria_buffer,tmp,1);
  return 1;
}
