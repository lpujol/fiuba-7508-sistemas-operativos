//                    thread/thr4.cc
#include <pthread.h>
#include <iostream>
#include <unistd.h>
#include <stdlib.h>
using namespace std;

// En Linux, forma "civilizada" de compartir variables 
// (sin globales pero con un show de * y &)
// y Semaforos (mutex) para sincronizar 
// compilar con -lpthread.

typedef struct {
	int variable;
	pthread_mutex_t mut;
	}compartida;

void *func(void *arg){
  compartida * par_p=reinterpret_cast<compartida *>(arg);

  for (int i=0; i<10;i++) {
  	pthread_mutex_lock(&par_p->mut);
  	(par_p->variable)++;
  	pthread_mutex_unlock(&(par_p->mut));
  	} 
  	cout<<"Thread "<<pthread_self() <<" variable vale "<<par_p->variable<<endl;
  return NULL;
}
int main(){
  pthread_t th1,th2;
  compartida var;
  pthread_mutex_init(&var.mut,NULL);
  var.variable=0;
  pthread_create(&th1,NULL,func,reinterpret_cast<void *>(&var));
  pthread_create(&th2,NULL,func,reinterpret_cast<void *>(&var));
  for(int i=0;i<10;i++){
  	pthread_mutex_lock(&var.mut);
	var.variable++;
	pthread_mutex_unlock(&var.mut);
	}
  pthread_join(th1,NULL);
  pthread_join(th2,NULL);	
  cout<<"main variable vale "<<var.variable<<endl;
}
